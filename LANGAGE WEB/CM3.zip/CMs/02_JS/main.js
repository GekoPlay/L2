


console.log("HOP")

// OLD
// getElementById
// getElementsByClassName
// getElementsByTagName

// NEW
// querySelector
// querySelectorAll


// x = appel(Kévin)
h1 = document.querySelector("h1")

console.log(h1)
h1.style.color = "red"
h1.innerHTML = "Javascript"
console.log(h1.innerHTML)

setInterval(function() {
	h1.classList.toggle("hop")
}, 500)
//--------------------------------
body = document.querySelector("body")


setInterval(function() {
	r = Math.floor((Math.random()*255))
	g = Math.floor((Math.random()*255))
	b = Math.floor((Math.random()*255))

	body.style.backgroundColor = "rgb("+r+","+g+","+b+")"

}, 150)
