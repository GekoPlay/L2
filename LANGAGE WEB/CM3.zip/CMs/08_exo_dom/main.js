
const data = [
	{
		name: "Bourdeau",
		image: "bourdeau.jpg",
		description: "Vue depuis les hauteurs du Bourget-du-Lac"
	},
	{
		name: "Campus",
		image: "campus.jpg",
		description: "Bouillon de neurones"
	},
	{
		name: "Chambotte",
		image: "chambotte.jpg",
		description: "Plein gaz"
	},
]


const body = document.querySelector("body")

// Affichage d'un titre
const h1 = document.createElement("h1")
h1.innerText = "Le Bourget-du-Lac"
body.appendChild(h1)

// Parcours des données

// for(let i=0; i<data.length(); i++) {
// 	let element = data[i]
// 	console.log(element)
// }
 
// for(let element of data) {
// 	console.log(element)
// }

data.forEach(element => {

	const article = document.createElement("article")
	body.appendChild(article)

	const h2 = document.createElement("h2")
	h2.innerText = element.name
	article.appendChild(h2)

	const img = document.createElement("img")
	img.src = "./images/"+element.image
	article.append(img)


})


