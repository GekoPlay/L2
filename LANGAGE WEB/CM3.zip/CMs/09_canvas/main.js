

const canvas = document.querySelector("canvas")
const c = canvas.getContext("2d")

const w = window.innerWidth
const h = window.innerHeight
canvas.width = w
canvas.height = h

const mouse = { x: 0, y: 0 }

canvas.addEventListener("mousemove", event => {
	mouse.x = event.pageX
	mouse.y = event.pageY
})

setInterval(_ => {
	c.clearRect(0,0, w,h)
	c.beginPath()
	c.moveTo(mouse.x,mouse.y)
	c.lineTo(w/2,h/2)
	c.strokeStyle = "#FFCC00"
	c.lineWidth = 5
	c.stroke()

	c.beginPath()
	c.arc(mouse.x, mouse.y, 50, 0, Math.PI*2)
	c.fillStyle = "lime"
	c.strokeStyle = "purple"
	c.lineWidth = 10
	c.fill()
	c.stroke()

}, 1)

