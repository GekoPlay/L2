

// Syntaxe

var x = 42  // global
let y = 73  // local
const z = 1.618


// JSON
const game = {
	name: "Tiny Glade",
	type: "Chill",
	year: 2024
}

console.log(game)

//---------------------------------------

if (game.year == "2024") {
	console.log("New")
} else {
	console.log("Old")
}

// for i in range(0,100):   // Python
for(let i=0; i<100; i++) {
	console.log(i)
}


const games = ["Tiny Glade", "Minecraft", "Worms"]
games.push("Chess")
console.log(games)

for(let i in games) {
	console.log(i)
}
for(let g of games) {
	console.log(g)
}













