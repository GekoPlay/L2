

const h1 = document.querySelector("h1")
const countDiv = document.querySelector("#count")

h1.style.backgroundColor = "lime"
h1.style.padding = "50px"

let count = 0

h1.addEventListener("click", function() {

	count++
	console.log("Clicks : " + count + " !")
	countDiv.innerHTML = "Clicks : " + count + " !"

})


