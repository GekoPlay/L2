
const div = document.querySelector("div")
const h = window.innerHeight

const ball = {
	x: 0,
	y: 0, 
	vx: 0.1,
	vy: 0
}


setInterval(function() {

	div.style.top = ball.y+"px"
	div.style.left = ball.x+"px"

	ball.x += ball.vx
	ball.y += ball.vy
	if (ball.y > h) {
		ball.y -= ball.vy
		ball.vy *= -0.95
	}
	ball.vy += 0.005


}, 1)
