

// FIRA CODE (Font)

// function m(x) {
// 	return x*2
// }

// const m = x => {
// 	return x*2
// }

// const m = x => x*2





const box = document.querySelector("#box")


box.addEventListener("click", event => {
	console.log(event)
})
box.addEventListener("mouseenter", event => {
	box.style.backgroundColor = "lime"
})
box.addEventListener("mouseleave", event => {
	setTimeout( _ => {
		box.style.backgroundColor = "orange"
	}, 500)
})


box.addEventListener("mousemove", event => {
	console.log(event.pageX+" "+event.pageY)
})
