
const body = document.querySelector("body")

// Création d'un tag <h1>
let h1 = document.createElement("h1")
// Ajout d'un texte à l'intérieur
h1.innerHTML = "Il fait trop beau pour coder !"
// Afficher
body.appendChild(h1)


