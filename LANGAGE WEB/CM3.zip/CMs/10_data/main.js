function create(tag, text, parent) {
	const element = document.createElement(tag)
	element.innerText = text
	parent.appendChild(element)
	return element
}

const food = [
	{
		name: "Pizza",
		healthy: true,
		price: 11.0
	},
	{
		name: "Burger",
		healthy: false,
		price: 9.0
	},
	{
		name: "Tiramisu",
		healthy: false,
		price: 8.0
	},
]

// -----------------------------------------------------ELEMENTS HTML

const foodSection = document.querySelector("#food")
const cartSection = document.querySelector("#cart")

// -----------------------------------------------------CART FUNCTIONS

const cart = []
function displayCart() {
	cartSection.innerText = ""
	cart.forEach( meal => {
		create("p", meal.name, cartSection)
	})
}

// -----------------------------------------------------DATA FUNCTIONS/ACTIONS

food.forEach( meal => {
	let article = create("article", "", foodSection)
	create("h2", meal.name, article)
	create("p", meal.healthy ? "Bon" : "Pas bon", article )
	create("p", meal.price+"€", article)

	let addButton = create("button", "🧺", article)
	addButton.addEventListener("click", event => {
		cart.push(meal)
		displayCart()
	})
})
