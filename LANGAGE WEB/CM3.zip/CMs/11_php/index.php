<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title></title>
	<style>
		img { width: 300px; }
	</style>
</head>
<body>

	<h1>PHP</h1>

	<!-- <img src="image.php"/> -->

	<?php

	$data = [
		[ "name" =>  "x",  "value" => 42 ],
		[ "name" =>  "y",  "value" => 73 ],
		[ "name" =>  "keyword",  "value" => "HOP" ],
	];

	// var_dump($data);

	echo(json_encode($data));



	?>




</body>
</html>


