<?php


echo(file_get_contents("burger.jpg"));

