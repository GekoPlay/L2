<?php



echo rand(0,20);

