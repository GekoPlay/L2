

const div = document.querySelector("div")

div.innerText = 0


setInterval(_ => {

	axios.get("random.php")
		.then(response =>  {
			console.log(response.data)
			div.innerText = response.data
		})


}, 1000)
