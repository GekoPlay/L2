package TP3;

public class Magicien implements Entites{
	private int posX;
	private int posY;
	
	public Magicien() {
	}
	@Override
	public String recupInitial() {
		return "W";
	}
	 
	 public void donnerToutLeGraal(Chevalier c, Entites[] listeGraals) {
	        System.out.println("Le Magicien Merlin utilise sa magie pour invoquer le Graal !");
	        for (Entites e : listeGraals) {
	            if (e instanceof Graal) {
	                c.setBag(e); 
	            }
	        }
	    }
	 
	public void setPosition(int nouvelleX, int nouvelleY) {
	    	this.posX = nouvelleX;
	    	this.posY = nouvelleY;
	    }
	
	 public int getX() {
		 return posX;
	 }
	 public int getY() {
		 return posY;
	 }
}
