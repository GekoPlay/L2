package TP3;

public interface Entites {
	public String recupInitial();
	public int getPv();
	public String getNom();
	public void setPv();
	}

