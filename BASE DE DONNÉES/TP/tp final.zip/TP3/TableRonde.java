package TP3;

import java.util.ArrayList;



public class TableRonde {
    private ArrayList<Chevalier> membres;
    
    
    
public TableRonde(){
	membres = new ArrayList<Chevalier>();
}
    
    public void ajouter(Chevalier c){
    	membres.add(c);
    }
    
    
    public Chevalier trouverParNom(String nomRecherche) {
        for (Chevalier c : membres) {
            if (c.getNom().equalsIgnoreCase(nomRecherche)) {
                return c; // On a trouvé, on retourne l'objet Chevalier
            }
        }
        return null; // On a fini la boucle sans rien trouver
    }
    

	
    
	public void supprimer(Chevalier c) {
		if (membres.contains(c)){
			membres.remove(c);
		}}
	
	
	@Override
	public String toString() {
		String res = "";
		for (Chevalier c : membres) {
			res = res + c + ", ";
		}
		return res;
	}

    
}
